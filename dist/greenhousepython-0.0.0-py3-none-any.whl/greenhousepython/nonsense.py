class cv2:
  def imread(path):
    return None
  def VideoWriter_fourcc(*args):
    return None
  def VideoWriter(output_video_path,fourcc,fps,size):
    return None
  def resize(frame,size):
    return None

class Picamera2:
  def __init__(self):
    pass
  def start(self):
    pass
  def create_still_configuration(self):
    pass
